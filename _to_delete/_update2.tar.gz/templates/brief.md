# Бриф задачи

```markdown
Понял так:
Режим: интерактив | решение (автономно, журнал решений)
Маршрут: Lightweight | Full | Operational/docs | R&D | scope | product | growth
Routing: L1/L2/L3 · модель · семья · task class
In scope:
Out of scope:
Проверки (evidence):
Риски:
Нужно от человека: none | …
Независимо продолжается:
Следующая роль:
```

Не ждать «делай», если поручение уже «сделай X» и трактовка одна.
